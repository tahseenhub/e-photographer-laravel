<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Shoot;
use App\User;
Use App\Cart;
Use App\Feedback;
Use App\Categories;

class adminController extends Controller
{
    //
    public function index(){
        $carts=Cart::all();
        $users=User::all();
        $users2=User::orderby('id','desc')->take(2)->get();
        $shoots=Shoot::all();
        $shoots2=Shoot::orderby('id','desc')->take(2)->get();
        $feedbacks=Feedback::all();
        $feedbacks2=Feedback::orderby('id','desc')->take(2)->get();
        return view('admin.home',['carts'=>$carts,'users'=>$users,'shoots'=>$shoots,'feedbacks'=>$feedbacks,'users2'=>$users2,'shoots2'=>$shoots2,'feedbacks2'=>$feedbacks2]);
    }
    public function users(){
        $users=User::all();
        return view('admin.users',['users'=>$users]);
    }
    public function shoots(){
        $shoots=Shoot::all();
        return view('admin.shoots',['shoots'=>$shoots]);
    }
    public function orders(){
        return view('admin.orders');
    }
    public function settings(){
        return view('admin.settings');
    }
    public function history(){
        return view('admin.settings');
    }
    public function usersBlock($id){
        $users=User::find($id);
        $users->status='block';
        $users->save();
        return redirect()->back();
    }
    public function usersAdd($id){
        $users=User::find($id);
        $users->status='active';
        $users->save();
        return redirect()->back();
    }
    public function ajaxSearchUsers($str){
        $users=User::where('name','like','%'.$str.'%')->get();
        return view('admin.ajaxSearchUsers',['users'=>$users]);
    }
    public function shootDelete($id){
        $users=Shoot::destroy($id);
 
        return redirect()->back();
    }
    public function ajaxUsersStatus($str){
        if ($str=="block") {
            $users=User::where('status',$str)->get();
            return view('admin.ajaxUsersStatus',['users'=>$users]);
            
        } elseif($str=="active") {
            $users=User::where('status',$str)->get();
            return view('admin.ajaxUsersStatus',['users'=>$users]);
        }else{
           $users=User::all();
            return view('admin.ajaxUsersStatus',['users'=>$users]); 
        }
    
    }
    public function ajaxUsersType($str){
        $users=User::where('type',$str)->get();
        return view('admin.ajaxUsersStatus',['users'=>$users]);
    }
    public function ajaxFreeShoots($str){
        if ($str=="free") {
            $shoots=Shoot::where('price','=','0')->get();
            return view('admin.ajaxFreeShoots',['shoots'=>$shoots]);    
        } elseif($str=="premium") {
            $shoots=Shoot::where('price','>','0')->get();
            return view('admin.ajaxFreeShoots',['shoots'=>$shoots]); 
        }else{
            $shoots=Shoot::all();
            return view('admin.ajaxFreeShoots',['shoots'=>$shoots]);
        }
    
    }
}
